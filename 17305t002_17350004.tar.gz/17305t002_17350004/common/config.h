#define CONMAX 1000
#define BYTES 1024
#define PORT_WEB  8080
#define PORT_WS 8001
#define ROOT "/home/r3v0/C_practice/webserver_project"
#define STD_HEADER "HostConnectionUser-AgentAcceptRefererAccept-EncodingCookieAccept-LanguageCache-ControlPragmaValue"
#define WS_URL "ws://10.15.28.171:8001"
