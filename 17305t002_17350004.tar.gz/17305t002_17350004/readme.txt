 ======================================
||Please update g++ to version 6.3.0+ ||
 ======================================

Set Conifguration
=================
change PORT_WEB , PORT_WS and WS_URL in common/config.h
default:
PORT_WEB  8080
PORT_WS 8001
WS_URL "ws://10.15.28.171:8001"

WS_URL should be in the form :
ws://<IPV4 of SERVER>:<PORT_WS>

Instruction to Run
==================

Compile both Websockt Server and Web Server

g++ webserver.c -std=c11 -pthread -o web_server.o
g++ ws_server.c -std=c11 -pthread -o ws_server.o

Run Compiled Binaries

./web_server.o
./ws_server.o

From the browser type the url localhost:8080    // default port is taken as 8080
create a game using palyer1 name. Suppose entered name is Himadri , then the game id will be shown as Himadrixx2   (Please donot press Enter in this stage as this exception has not been handled).
Open another brwoser or use the same browser in incognito mode and go the the url localhost:8080
From another browser enter the player two name in the appropriate place and then enter game id of the created game (example Himadrixx2) , in the above case.

A new URL will open where two players can now play with eath other

Instruction to Test
===================

The Server sets cookie so , to test multiple occourance , must use one tab
from normal mode and one from incognito mode .



